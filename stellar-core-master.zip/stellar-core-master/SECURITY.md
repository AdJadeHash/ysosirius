# Security Policy and reporting a Vulnerability

stellar-core falls under the Stellar Foundation's bug bounty program.

To report a security problem and review the details of the program, see the [Stellar bug bounty program](https://www.stellar.org/bug-bounty-program/).
