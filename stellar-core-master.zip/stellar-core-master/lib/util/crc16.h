#pragma once
#include <cstdint>

uint16_t crc16(const char *buf, int len);
