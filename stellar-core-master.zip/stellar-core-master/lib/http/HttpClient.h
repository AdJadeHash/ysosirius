
// synchronous request
int http_request(std::string domain, std::string path, unsigned short port, std::string& ret);
